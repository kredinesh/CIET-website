import React from 'react';
function Home(){
    return(
<html>
    <body background-color='green'>
        This is home page
    </body>
</html>
    );
}
export default Home;

