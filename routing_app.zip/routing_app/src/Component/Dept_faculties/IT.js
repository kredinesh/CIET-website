import React from 'react'

export default function IT() {
    return (
        <div>
            <div className="First">
                <h1>This is IT department</h1></div>            
        </div>
    )
}
