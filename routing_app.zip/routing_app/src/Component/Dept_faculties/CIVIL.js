import React from 'react'

export default function CIVIL() {
    return (
        <div>
            <div className="First">
                <h1>This is Civil department</h1></div>            
        </div>
    )
}
