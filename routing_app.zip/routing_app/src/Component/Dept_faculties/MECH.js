import React from 'react'

export default function MECH() {
    return (
        <div>
            <h4>This is MECHANICAL DEPARTMENT</h4>
        </div>
    )
}
